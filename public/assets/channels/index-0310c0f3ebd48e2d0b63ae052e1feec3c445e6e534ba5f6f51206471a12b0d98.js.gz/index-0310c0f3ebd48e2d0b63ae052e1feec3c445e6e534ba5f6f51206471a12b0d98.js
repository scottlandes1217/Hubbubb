// This file is intentionally empty.
// Turbo Streams handles the WebSocket connection automatically.;
